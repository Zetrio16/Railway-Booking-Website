package DatabaseHandler;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import BusinessLayer.Booking;
import BusinessLayer.Registration;
import BusinessLayer.Station;
import BusinessLayer.Train;
import BusinessLayer.admin;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;


public class DBHandler{
	
	private static DBHandler instance = null;
	private DBHandler()
	{}

	public static synchronized DBHandler getInstance()
	{
		if(instance == null)
		{
			instance = new DBHandler();	
		}
		return instance;
	}
	
	
	public Boolean ValidateAdmin(String username, String passcode) throws SQLException, ClassNotFoundException{
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sakila", "root", "PASSWORD-123");
    	
    	PreparedStatement ps = con.prepareStatement("select * from admin");
    	ResultSet rs = ps.executeQuery();
    	
    	while(rs.next())
    	{
    		String dbusername = rs.getString("username");
    		String dbpass = rs.getString("password");
    		
    		if(username.contentEquals(dbusername) && passcode.contentEquals(dbpass))
    		{
    			return true;
    		}
    	}
    	
    	String Errors = "Wrong username or password";
		Alert errorAlert = new Alert(AlertType.ERROR);
		errorAlert.setTitle("Login Unsuccessful");
		errorAlert.setContentText(Errors);
		errorAlert.show(); 
		
		admin ad = new admin(username,passcode);
    	return false;
	}
	
	public Boolean ValidateCustomer(String CustomerName, String CustomerCnic,  String address, String phoneNo) throws SQLException, ClassNotFoundException{
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/RMS", "root", "1234");
		
		PreparedStatement ps = con.prepareStatement("select * from customer where customer.cnic='"+CustomerCnic+"';");
		ResultSet rs = ps.executeQuery();
		
		while(rs.next())
		{
			String cnicOfCustomer = rs.getString("cnic");
			
			if(CustomerCnic.contentEquals(cnicOfCustomer))
			{
				String Errors = "Cannot Register due to invalid or registered cnic";
				Alert errorAlert = new Alert(AlertType.ERROR);
				errorAlert.setTitle("Registration Unsuccessful");
				errorAlert.setContentText(Errors);
				errorAlert.show(); 
				return false;
			}
		}
    	
		PreparedStatement pstmt = con.prepareStatement("INSERT INTO customer(customerName, cnic, customerAddress, phoneNum) VALUES (?,?,?,?);");
		pstmt.setString(1, CustomerName);
		pstmt.setString(2, CustomerCnic);
		pstmt.setString(3, address);
		pstmt.setString(4, phoneNo);
		pstmt.executeUpdate();
		
		Registration reg = new Registration(CustomerName, CustomerCnic, address, phoneNo);
		return true;
	}
	
	
	public Boolean BookingConfirmed(String cnic, String nameofTrain, String arrival, String destination, int no_of_Seats) throws ClassNotFoundException, SQLException
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/RMS", "root", "1234");
		
		PreparedStatement ps = con.prepareStatement("select * from customer where customer.cnic='"+cnic+"';");
		ResultSet rs = ps.executeQuery();
		
		while(rs.next())
		{
			String cnicOfCustomer = rs.getString("cnic");
			
			if(!cnic.contentEquals(cnicOfCustomer))
			{
				String Errors = "Cannot book the ticket due to invalid or registered cnic";
				Alert errorAlert = new Alert(AlertType.ERROR);
				errorAlert.setTitle("Booking Unsuccessful");
				errorAlert.setContentText(Errors);
				errorAlert.show();
				return false;
			}
		}
		
		PreparedStatement ps1 = con.prepareStatement("select * from train where train.NameOfTr='"+nameofTrain+"'AND train.trainfrom='"+arrival+"' AND train.trainto='"
		+destination+"';");
		
		ResultSet rs1 = ps1.executeQuery();
//		
//		while(rs1.next())
//		{
//			String train_Name = rs1.getString("NameOfTr");
//			String train_arrival = rs1.getString("trainfrom");
//			String train_destination = rs1.getNString("trainto");
//			
//			if(!(train_Name.contentEquals(nameofTrain)) && (train_arrival.contentEquals(arrival)) && (train_destination.contentEquals(destination))) 
//			{
//				String Errors = "Train does not exist! Please enter correct Train Name";
//				Alert errorAlert = new Alert(AlertType.ERROR);
//				errorAlert.setTitle("Booking Unsuccessful");
//				errorAlert.setContentText(Errors);
//				errorAlert.show();
//				return false;
//			}
			
//			if(!train_arrival.contentEquals(arrival))
//			{
//				String Errors = "This specific train does not go from the entered Place!";
//				Alert errorAlert = new Alert(AlertType.ERROR);
//				errorAlert.setTitle("Booking Unsuccessful");
//				errorAlert.setContentText(Errors);
//				errorAlert.show();
//				return false;
//			}
//				
//			if(!train_destination.contentEquals(destination))
//			{
//				String Errors = "This specific train does not go to the entered Place!";
//				Alert errorAlert = new Alert(AlertType.ERROR);
//				errorAlert.setTitle("Booking Unsuccessful");
//				errorAlert.setContentText(Errors);
//				errorAlert.show();
//				return false;
//			}
//		}
		
		PreparedStatement pstmt = con.prepareStatement("INSERT INTO booking VALUES (?,?,?,?,?);");
		pstmt.setString(1, cnic);
		pstmt.setString(2, nameofTrain);
		pstmt.setString(3, arrival);
		pstmt.setString(4, destination);
		pstmt.setInt(5, no_of_Seats);
		pstmt.executeUpdate();
		
		
		int fare = no_of_Seats*1000;
		
		String fare_amount = "Calculated fare is "+ fare;
		Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Fare Amount");
        alert.setContentText(fare_amount);
        alert.show();
        
		System.out.print("Calculated cost is ");
		System.out.println(fare);
		
		Booking bookTicket = new Booking(cnic,nameofTrain,arrival,destination,no_of_Seats);	
		
		return true;
	
	}
	
	public Boolean ValidateCustomerForCancelBooking(String cnic) throws SQLException, ClassNotFoundException{
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/RMS", "root", "1234");
		
		PreparedStatement ps = con.prepareStatement("select * from  booking where booking.CnicOfCustomer='"+cnic+"';");
		ResultSet rs = ps.executeQuery();
		
		while(rs.next())
		{
			String cnicOfCustomer = rs.getString("CnicOfCustomer");
			
			if(!cnic.contentEquals(cnicOfCustomer))
			{
				String Errors = "No ticket has been booked on the entered cnic";
				Alert errorAlert = new Alert(AlertType.ERROR);
				errorAlert.setTitle("Booking Unsuccessful");
				errorAlert.setContentText(Errors);
				errorAlert.show();
				return false;
			}
		}
		
//		PreparedStatement ps1 = con.prepareStatement("DELETE FROM booking where booking.CnicOfCustomer='"+cnic+"';");
		Statement st = con.createStatement();
		int rs1 = st.executeUpdate("DELETE FROM booking where booking.CnicOfCustomer='"+cnic+"';");
		
		
		return true;
	}
	
	
	public Boolean AdminBookingConfirmed(String cnic, String nameofTrain, String arrival, String destination, int no_of_Seats) throws ClassNotFoundException, SQLException
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/RMS", "root", "1234");
		
		PreparedStatement ps = con.prepareStatement("select * from booking where booking.CnicOfCustomer ='"+cnic+"';");
		ResultSet rs = ps.executeQuery();
		
		while(rs.next())
		{
			String cnicOfCustomer = rs.getString("CnicOfCustomer");
			
			if(!cnic.contentEquals(cnicOfCustomer))
			{
				String Errors = "Cannot book the ticket due to invalid or registered cnic";
				Alert errorAlert = new Alert(AlertType.ERROR);
				errorAlert.setTitle("Booking Unsuccessful");
				errorAlert.setContentText(Errors);
				errorAlert.show();
				return false;
			}
		}
		
		PreparedStatement ps1 = con.prepareStatement("select * from train where train.NameOfTr='"+nameofTrain+"'AND train.trainfrom='"+arrival+"' AND train.trainto='"
		+destination+"';");
		
		ResultSet rs1 = ps1.executeQuery();
//		
//		while(rs1.next())
//		{
//			String train_Name = rs1.getString("NameOfTr");
//			String train_arrival = rs1.getString("trainfrom");
//			String train_destination = rs1.getNString("trainto");
//			
//			if(!(train_Name.contentEquals(nameofTrain)) && (train_arrival.contentEquals(arrival)) && (train_destination.contentEquals(destination))) 
//			{
//				String Errors = "Train does not exist! Please enter correct Train Name";
//				Alert errorAlert = new Alert(AlertType.ERROR);
//				errorAlert.setTitle("Booking Unsuccessful");
//				errorAlert.setContentText(Errors);
//				errorAlert.show();
//				return false;
//			}
			
//			if(!train_arrival.contentEquals(arrival))
//			{
//				String Errors = "This specific train does not go from the entered Place!";
//				Alert errorAlert = new Alert(AlertType.ERROR);
//				errorAlert.setTitle("Booking Unsuccessful");
//				errorAlert.setContentText(Errors);
//				errorAlert.show();
//				return false;
//			}
//				
//			if(!train_destination.contentEquals(destination))
//			{
//				String Errors = "This specific train does not go to the entered Place!";
//				Alert errorAlert = new Alert(AlertType.ERROR);
//				errorAlert.setTitle("Booking Unsuccessful");
//				errorAlert.setContentText(Errors);
//				errorAlert.show();
//				return false;
//			}
//		}
		
		PreparedStatement pstmt = con.prepareStatement("INSERT INTO booking VALUES (?,?,?,?,?);");
		pstmt.setString(1, cnic);
		pstmt.setString(2, nameofTrain);
		pstmt.setString(3, arrival);
		pstmt.setString(4, destination);
		pstmt.setInt(5, no_of_Seats);
		pstmt.executeUpdate();
		
		int fare = no_of_Seats*1000;
		
		String fare_amount = "Calculated fare is "+ fare;
		Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Fare Amount");
        alert.setContentText(fare_amount);
        alert.show();
        
		Booking bookTicket = new Booking(cnic,nameofTrain,arrival,destination,no_of_Seats);	
		
		return true;
	}
	
	public Boolean addTrainConfirmed(String nameofTrain, String arrival, String destination) throws ClassNotFoundException, SQLException
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/RMS", "root", "1234");
		
		PreparedStatement ps = con.prepareStatement("select * from train where train.NameOfTr ='"+nameofTrain+"';");
		ResultSet rs = ps.executeQuery();
		
		while(rs.next())
		{
			String train_name = rs.getString("NameOfTr");
			
			if(nameofTrain.contentEquals(train_name))
			{
				String Errors = "Cannot add the train due to invalid or already used train name";
				Alert errorAlert = new Alert(AlertType.ERROR);
				errorAlert.setTitle("add Train Unsuccessful");
				errorAlert.setContentText(Errors);
				errorAlert.show();
				return false;
			}
		}
		
		PreparedStatement ps1 = con.prepareStatement("Insert into train Values(?,?,?)");
		ps1.setString(1, nameofTrain);
		ps1.setString(2, arrival);
		ps1.setString(3, destination);
		ps1.executeUpdate();
		
		
		Train addTrain = new Train(nameofTrain,arrival,destination);
		
		return true;
	}

	public ResultSet BookingCnicExists(String updateBooking_Cnic) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/RMS", "root", "1234");
		Statement ps = con.createStatement();
		ResultSet rs = ps.executeQuery("select * from booking where booking.CnicOfCustomer ='"+updateBooking_Cnic+"';");
		return rs;
	}

	public void updateBooking(String updateBooking_Cnic,String updateBooking_TrainName, String updateBooking_arrival,
			String updateBooking_destination, int updateBooking_noOfSeats) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/RMS", "root", "1234");
		
		String query = "update booking set trainName='"+updateBooking_TrainName+"',arrival='"+updateBooking_arrival+"',dest='"
				+updateBooking_destination+"',numbOfSeats='"+updateBooking_noOfSeats+"' where CnicOfCustomer='"+updateBooking_Cnic+"';";
		
		Statement st = con.createStatement();
		int rs = st.executeUpdate(query);
	}

	public boolean validateTrainDeletion(String deleteTrain_Name) throws SQLException, ClassNotFoundException {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/RMS", "root", "1234");
		
		PreparedStatement ps = con.prepareStatement("select * from  train where train.NameOfTr='"+deleteTrain_Name+"';");
		ResultSet rs = ps.executeQuery();
		
		while(rs.next())
		{
			String train_Name_del = rs.getString("NameOfTr");
			
			if(!train_Name_del.contentEquals(deleteTrain_Name))
			{
				String Errors = "Train does not Exist";
				Alert errorAlert = new Alert(AlertType.ERROR);
				errorAlert.setTitle("Train Not Found");
				errorAlert.setContentText(Errors);
				errorAlert.show();
				return false;
			}
		}
//		PreparedStatement ps1 = con.prepareStatement("DELETE FROM booking where booking.CnicOfCustomer='"+cnic+"';");
		Statement st = con.createStatement();
		int rs1 = st.executeUpdate("DELETE FROM train where train.NameOfTr='"+deleteTrain_Name+"';");
		return true;
	}

	public void train_UpdateValidate(String updateTrain_TrainName, String updateTrain_arrival, String updateTrain_dest) throws SQLException, ClassNotFoundException {
		
		// TODO Auto-generated method stub
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/RMS", "root", "1234");
		
		String query = "update train set NameOfTr='"+updateTrain_TrainName+"',trainfrom='"+updateTrain_arrival+"', trainto='"
				+updateTrain_dest+"';";
		
		Statement st = con.createStatement();
		int rs = st.executeUpdate(query);
		
	}

	public void addTrainStation(String stationName) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/RMS", "root", "1234");
		Station st = new Station(stationName);
	}
	
	
}