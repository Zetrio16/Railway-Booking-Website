package BusinessLayer;

public class Luggage {

}