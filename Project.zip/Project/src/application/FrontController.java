package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import BusinessLayer.Booking;
import DatabaseHandler.DBHandler;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class FrontController{
    
	//////////////////////////////////   MAIN MENU ???????????????? ///////////////////////////////////////
	@FXML
	private Button AdminLoginButton;

	@FXML
	private Button CustomerReg;
    
    @FXML
    void LogtheAdmin(ActionEvent event) throws IOException {
    	BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("AdminLogin.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
         stage.show();
    }
   
    
    @FXML
    void RegisterCustomer(ActionEvent event) throws IOException{
    	BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("Register.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    
    
    ////////////////////////////////////  ADMIN LOGIN PAGE ???????? /////////////////////////////////////
    
    @FXML
    private Button butLog1;

    @FXML
    private TextField NameOfUser;

    @FXML
    private TextField passcode;

    String adminUsername = null;
    String adminPassword = null;
    
    
    @FXML
    void Admin_Button_Submit(ActionEvent event) throws IOException, SQLException, ClassNotFoundException {
    	
    	adminUsername = NameOfUser.getText();
    	adminPassword = passcode.getText();
    	
    	DBHandler dbHandler = DBHandler.getInstance();
    	boolean validateAdmin = dbHandler.ValidateAdmin(adminUsername, adminPassword);
    	
    	System.out.println(validateAdmin);
    	
    	if(validateAdmin)
    	{
    		BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("AdminMenu.fxml"));
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
    	}
    }

    
    
    /////////////////////////////////  CUSTOMER REGISTRATION PAGE ???????? ///////////////////////////////
    
    
    @FXML
    private TextField address;

    @FXML
    private TextField cnic;

    @FXML
    private TextField fullName;

    @FXML
    private TextField phoneNum;

    @FXML
    private Button registerButton;
    
    String custName = "";
    String custCnic = "";
    String custAddr = "";
    String custNumb = "";
    		

    @FXML
    void CustomerRegistered(ActionEvent event)  throws IOException, ClassNotFoundException, SQLException{
    	
    	custName = fullName.getText();
    	custCnic = cnic.getText();
    	custAddr = address.getText();
    	custNumb = phoneNum.getText();
    	
    	DBHandler dbHandler = DBHandler.getInstance();
    	boolean validateCustomer = dbHandler.ValidateCustomer(custName, custCnic, custAddr, custNumb);
    	
    	System.out.println(validateCustomer);
    	
    	if(validateCustomer)
    	{
    		BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("CustomerMenu.fxml"));
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
            
    	}
    
    }
    
    
    
    //////////////////////////////////////  CUSTOMER MENU PAGE ???????????????????? ////////////////////////////
    
    @FXML
    private Button bookTicketButton;

    @FXML
    private Button cancelTicketButton;

    @FXML
    private Button seatChangeButton;

    @FXML
    void ProceedToSeatChange(ActionEvent event) throws IOException{
    	BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("RequestSeatChange.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void ProceedToTicketBooking(ActionEvent event) throws IOException{
    	BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("TicketBooking.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void ProceedToTicketCancellation(ActionEvent event) throws IOException{
    	BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("TicketCancellation.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    
    //////////////////////// RESERVE TICKET ????????????? //////////////////////
     
    @FXML
    private TextField ArrivalText;

    @FXML
    private TextField DestinationText;

    @FXML
    private TextField NumberOfSeatsText;

    @FXML
    private Button ReserveBookingButton;

    @FXML
    private TextField TrainNameText;

    @FXML
    private TextField cnicText;
    
    
    String booking_Cnic="";
    String booking_train="";
    String booking_arrival="";
    String booking_dest="";
    String booking_NoOfSeats="";

    
    
    @FXML
    void BookingReserved(ActionEvent event) throws IOException, ClassNotFoundException, SQLException {
    	
    	booking_Cnic = cnicText.getText();
    	booking_train = TrainNameText.getText();
    	booking_arrival = ArrivalText.getText();
    	booking_dest = DestinationText.getText();
    	booking_NoOfSeats = NumberOfSeatsText.getText();
    	
    	int seats = Integer.parseInt(booking_NoOfSeats);
    	
    	DBHandler dbHandler = DBHandler.getInstance();
    	boolean reserveTicket = dbHandler.BookingConfirmed(booking_Cnic, booking_train, booking_arrival, booking_dest, seats);
    	
    	System.out.println(reserveTicket);
    	
    	if(reserveTicket)
    	{
    		BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("SuccessfulPrompt.fxml"));
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
    	}
    }
    
       
    ////////////////////////  SUCCESSFULL PROMPT ????????????? .///////////////////////////////
    
    @FXML
    private Button homeButton;

    @FXML
    private Button previousTabButton;

    @FXML
    void ProceedToHome(ActionEvent event) throws IOException{
    	BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("Main.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void ProceedToPreviousTab(ActionEvent event) throws IOException{
    	BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("CustomerMenu.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    
    /////////////////////////////  CANCEL BOOKING CUSTOMER ??????????????///////////////////////
    
    @FXML
    private TextField CNICTextInCancelTicket;

    @FXML
    private Button cancelButtonforTicket;
    
    String cnic_CancelBooking="";
    
    
    @FXML
    void CancelledTicketPrompt(ActionEvent event)  throws IOException, ClassNotFoundException, SQLException{
    	
    	cnic_CancelBooking = CNICTextInCancelTicket.getText();
    	
    	DBHandler dbHandler = DBHandler.getInstance();
    	boolean cancelBooking = dbHandler.ValidateCustomerForCancelBooking(cnic_CancelBooking);
    	
    	System.out.println(cancelBooking);
    	
    	if(cancelBooking)
    	{
    		BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("SuccessfulPrompt.fxml"));
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
    	}
    }
    
    
    
    /////////////////////////////  REQUEST SEAT CHANGE TICKET PROMPT PAGE ??????????????///////////////////////
    @FXML
    private Button FinalSeatButton;

    @FXML
    private TextField NewSeatNumber;

    @FXML
    private TextField TicketNumSeat;

    @FXML
    private TextField seatNumOriginal;

    @FXML
    void SeatChangedPrompt(ActionEvent event) throws IOException{
    	BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("SuccessfulPrompt.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }

    
    
    /////////////////////////   ADMIN MENU PAGE ??????????????????/////////////////////////////
    @FXML
    private Button buttonBooking;

    @FXML
    private Button buttonLuggage;

    @FXML
    private Button buttonStation;

    @FXML
    private Button buttonTrains;

    @FXML
    void BookingManager(ActionEvent event) throws IOException{
    	BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("ManageBooking.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    void LuggageManager(ActionEvent event) throws IOException{
    	BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("ManageLuggage.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    void StationManager(ActionEvent event) throws IOException{
    	BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("ManageStation.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    void TrainManager(ActionEvent event) throws IOException{
    	BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("ManageTrains.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }
    
    
    ////////////////////////// MANAGE BOOKING ADMIN PAGE ????????????????///////////////////////////////////
    @FXML
    private Button AddBookingAdminButton;

    @FXML
    private Button DeleteBookingAdminButton;

    @FXML
    private Button UpdateBookingAdminButton;
    

    @FXML
    void ProceedtoAddBooking(ActionEvent event) throws IOException{
    	BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("AddBooking.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    void ProceedtoDeleteBooking(ActionEvent event) throws IOException{
    	BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("deleteBooking.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }
    
    @FXML
    void ProceedtoUpdateBooking(ActionEvent event) throws IOException{
    	BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("updateBooking.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }
    
    /////////////////////////  ADD BOOKING ADMIN PAGE ?????????/////////////////////////
    @FXML
    private TextField ArrivalAdminText;

    @FXML
    private TextField DestinationAdminText;

    @FXML
    private TextField NumberOfSeatsAdminText;

    @FXML
    private TextField TrainNameAdminText;

    @FXML
    private Button addBookingAdmin;

    @FXML
    private TextField cnicAdminText;

    String Adminbooking_Cnic="";
    String Adminbooking_train="";
    String Adminbooking_arrival="";
    String Adminbooking_dest="";
    String Adminbooking_NoOfSeats="";
    
    @FXML
    void AddedBooking(ActionEvent event) throws IOException, ClassNotFoundException, SQLException{
    	
    	Adminbooking_Cnic = cnicAdminText.getText();
    	Adminbooking_train = TrainNameAdminText.getText();
    	Adminbooking_arrival = ArrivalAdminText.getText();
    	Adminbooking_dest = DestinationAdminText.getText();
    	Adminbooking_NoOfSeats = NumberOfSeatsAdminText.getText();
    	
    	int adminSeats = Integer.parseInt(Adminbooking_NoOfSeats);
    	
    	DBHandler dbHandler = DBHandler.getInstance();
    	boolean AdminValidateBooking = dbHandler.AdminBookingConfirmed(Adminbooking_Cnic, Adminbooking_train, Adminbooking_arrival, Adminbooking_dest, adminSeats);
    	
    	System.out.println(AdminValidateBooking);
    	
    	if(AdminValidateBooking)
    	{
    		BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("AdminPromptSuccessful.fxml"));
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
    	}

    }
    
    ///////////////////////////// 	DELETE BOOKING ADMIN PAGE ????????????/////////////////////////////////
    @FXML
    private TextField CNICTextInAdminPanel;

    @FXML
    private Button cancelButtonforAdmin;

    String cnicAdminuse ="";
    
    @FXML
    void adminCancelledBooking(ActionEvent event) throws IOException, ClassNotFoundException, SQLException{
    	
    	cnicAdminuse = CNICTextInAdminPanel.getText();
    	
    	DBHandler dbHandler = DBHandler.getInstance();
    	boolean adminvalidatebookingcancellation = dbHandler.ValidateCustomerForCancelBooking(cnicAdminuse);
    	
    	System.out.println(adminvalidatebookingcancellation);
    	
    	if(adminvalidatebookingcancellation)
    	{
    		BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("AdminPromptSuccessful.fxml"));
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
    	}

    }
    
    ///////////////////////////////// UPDATE BOOKING ADMIN PAGE ??????????????????/////////////////////////
    String updateBooking_Cnic="";
    String updateBooking_TrainName="";
    String updateBooking_destination="";
    String updateBooking_arrival="";
    int updateBooking_noOfSeats;
    
    
    @FXML
    private TextField ArrivalupdateText;

    @FXML
    private TextField DestinationupdateText;

    @FXML
    private TextField NumberOfSeatsupdateText;

    @FXML
    private TextField TrainNameUpdateText;

    @FXML
    private TextField cnicUpdateText;

    @FXML
    private Button updateBookingAdmin;

    @FXML
    private Button findOtherInfoButton;
    
    @FXML
    void foundDetails(ActionEvent event) throws ClassNotFoundException, SQLException {
    	updateBooking_Cnic=cnicUpdateText.getText();
    	DBHandler db=DBHandler.getInstance();
    	ResultSet rs=db.BookingCnicExists(updateBooking_Cnic);
    	
    	if(!rs.isBeforeFirst()) {

			String Errors = "Cannot add the train due to invalid or already used train name";
			Alert errorAlert = new Alert(AlertType.ERROR);
			errorAlert.setTitle("add Train Unsuccessful");
			errorAlert.setContentText(Errors);
			errorAlert.show();
    	}
    	while(rs.next()) {
    	TrainNameUpdateText.setText(rs.getString("trainName"));
    	ArrivalupdateText.setText(rs.getString("arrival"));
    	DestinationupdateText.setText(rs.getString("dest"));
    	NumberOfSeatsupdateText.setText(rs.getString("numbOfSeats"));
    	}
    }
    
    @FXML
    void updatedBooking(ActionEvent event) throws IOException, ClassNotFoundException, SQLException {
    	
         updateBooking_TrainName=TrainNameUpdateText.getText();
         updateBooking_destination=DestinationupdateText.getText();
         updateBooking_arrival=ArrivalupdateText.getText();
         updateBooking_noOfSeats=Integer.parseInt(NumberOfSeatsupdateText.getText());
         
         DBHandler db=DBHandler.getInstance();
         db.updateBooking(updateBooking_Cnic,updateBooking_TrainName,updateBooking_arrival,updateBooking_destination,updateBooking_noOfSeats);
    	
    	BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("AdminPromptSuccessful.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    
    
    //////////////////////////     MANAGE TRAINS ADMIN PAGE ????????????????///////////////////////////////////
    @FXML
    private Button addTrainAdminButton;
    
    @FXML
    private Button deleteTrainAdminButton;

    @FXML
    private Button updateTrainButton;

    @FXML
    void ProceedToAddTrain(ActionEvent event) throws IOException{
    	BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("addTrain.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    void ProceedToDeleteTrain(ActionEvent event) throws IOException{
    	BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("deleteTrain.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    void ProceedToUpdateTrain(ActionEvent event) throws IOException{
    	BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("updateTrain.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    } 
    
    ////////////////////////////////////// ADD TRAIN ADMIN PAGE ?????????????????////////////////////////////
    
    @FXML
    private TextField addArrivalText;

    @FXML
    private TextField addDestinationText;

    @FXML
    private TextField addTrainNameText;

    @FXML
    private Button addTrainbyAdmin;

    
    String nameofTrainAdmin ="";
    String arrivalAdmin=""; 
    String destinationAdmin="";
    @FXML
    void AddedTrainbyAdmin(ActionEvent event) throws IOException, ClassNotFoundException, SQLException{
    	
    	nameofTrainAdmin = addTrainNameText.getText();
    	arrivalAdmin = addArrivalText.getText();
    	destinationAdmin = addDestinationText.getText();
    	
    	DBHandler dbHandler = DBHandler.getInstance();
    	boolean validateAddTrain = dbHandler.addTrainConfirmed(nameofTrainAdmin, arrivalAdmin, destinationAdmin);
    	
    	System.out.println(validateAddTrain);
    	
    	if(validateAddTrain)
    	{
    		BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("AdminPromptSuccessful.fxml"));
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
    	}

    } 

    /////////////////////////////	 DELETE TRAIN ADMIN PAGE?????????????????///////////////////////////////
    @FXML
    private TextField deleteArrivalText;

    @FXML
    private TextField deleteDestinationText;

    @FXML
    private Button deleteTrainButton;

    @FXML
    private TextField deleteTrainText;

    String deleteTrain_Name ="";
    String deleteTrain_Arrival ="";
    String deleteTrain_Dest ="";
    @FXML
    
    void deletedTrain(ActionEvent event) throws IOException, ClassNotFoundException, SQLException {
        	
    	deleteTrain_Name = deleteTrainText.getText();
    	deleteTrain_Arrival = deleteArrivalText.getText();
    	deleteTrain_Dest = deleteDestinationText.getText();
        	
        DBHandler dbHandler = DBHandler.getInstance();
        boolean del_Train = dbHandler.validateTrainDeletion(deleteTrain_Name);
        	
        System.out.println(del_Train);
        	
        if(del_Train)
        {
        	BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("AdminPromptSuccessful.fxml"));
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }

    }
    
    ///////////////////////////////// UPDATE TRAIN ADMIN PAGE ??????????????????/////////////////////////
    
    
    @FXML
    private TextField updateArrivalText;

    @FXML
    private TextField updateDestinationText;

    @FXML
    private Button button_updateTrain;
    
    @FXML
    private TextField updateTrainText;
    
    String updateTrain_TrainName="";
    String updateTrain_dest="";
    String updateTrain_arrival="";
    
    @FXML
    void updatedTrain(ActionEvent event) throws ClassNotFoundException, SQLException, IOException{
    	
    	updateTrain_TrainName = updateTrainText.getText();
    	updateTrain_arrival = updateArrivalText.getText();
    	updateTrain_dest = updateDestinationText.getText();
    	
    	DBHandler db = DBHandler.getInstance();
    	db.train_UpdateValidate(updateTrain_TrainName, updateTrain_arrival, updateTrain_dest);
    	
    	BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("AdminPromptSuccessful.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    	
    
    
    
    //////////////////////////     MANAGE STATION ADMIN PAGE ????????????????///////////////////////////////////
    String stationName="";
    @FXML
    private TextField StationNameText;

    @FXML
    private TextField StationNumText;

    @FXML
    private Button addStationButton;

    @FXML
    private Button deleteStationButton;

    @FXML
    private Button updateStationButton;

    @FXML
    void ProceedToDeleteStation(ActionEvent event) throws IOException{
    	
    	BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("AdminPromptSuccessful.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    void ProceedToUpdateStation(ActionEvent event) throws IOException{
    	BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("AdminPromptSuccessful.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    void ProceedToaddStation(ActionEvent event) throws IOException, ClassNotFoundException, SQLException{
    	
    	stationName=StationNameText.getText();
    	
    	DBHandler dbb = DBHandler.getInstance();
    	dbb.addTrainStation(stationName);
    	BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("AdminPromptSuccessful.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    } 
    
    //////////////////////////     MANAGE LUGGAGE ADMIN PAGE ????????????????///////////////////////////////////
    @FXML
    private TextField ArrivalForLuggage;

    @FXML
    private TextField DestForLuggage;

    @FXML
    private TextField LuggageNum;

    @FXML
    private TextField LuggageWeight;

    @FXML
    private TextField TicketNumForLuggage;

    @FXML
    private TextField TrainNumForLuggage;

    @FXML
    private Button addLuggage;

    @FXML
    private Button deleteLuggage;

    @FXML
    private Button updateLuggage;

    @FXML
    void ProceedToAddLuggage(ActionEvent event) throws IOException{
    	BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("AdminPromptSuccessful.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    void ProceedToDeleteLuggage(ActionEvent event)throws IOException{
    	BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("AdminPromptSuccessful.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    void ProceedToUpdateLuggage(ActionEvent event)throws IOException{
    	BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("AdminPromptSuccessful.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }
    
    
    ////////////////////////////  ADMIN SUCCESSFUL PROMPT PAGE ??????????????////////////////
    @FXML
    private Button AdminHomeButton;

    @FXML
    private Button BackToAdminMenuButton;

    @FXML
    void FromAdminControlToHome(ActionEvent event) throws IOException{
    	BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("Main.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    @FXML
    void ProceedToAdminMenu(ActionEvent event) throws IOException{
    	BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("AdminMenu.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}